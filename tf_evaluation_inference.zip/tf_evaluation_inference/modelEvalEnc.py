#=======================================================================================================================
#=======================================================================================================================
import numpy as np
import tensorflow as tf
from modelDesign_48 import *
import scipy.io as sio
#=======================================================================================================================
#=======================================================================================================================
# Parameters Setting
NUM_FEEDBACK_BITS1 = 48
NUM_FEEDBACK_BITS2 = 128
CHANNEL_SHAPE_DIM1 = 12
CHANNEL_SHAPE_DIM2 = 32
CHANNEL_SHAPE_DIM3 = 2
CHANNEL_SHAPE_DIM_TOTAL = CHANNEL_SHAPE_DIM1 * CHANNEL_SHAPE_DIM2 * CHANNEL_SHAPE_DIM3
NUM_SAMPLES = 80000
EN_BATCH_SIZE = 64
#=======================================================================================================================
#=======================================================================================================================
# Data Loading
mat = sio.loadmat('channelData/W_test.mat')
data = mat['W_test']
# 该行不同
data = np.reshape(data, (NUM_SAMPLES, CHANNEL_SHAPE_DIM1, CHANNEL_SHAPE_DIM2, CHANNEL_SHAPE_DIM3))
data_test = np.reshape(data, [NUM_SAMPLES, -1])
#=======================================================================================================================
#=======================================================================================================================
# Model Loading
encoder_address1 = './modelSubmit/encoder_'+str(NUM_FEEDBACK_BITS1)+'.h5'
encoder_address2 = './modelSubmit/encoder_'+str(NUM_FEEDBACK_BITS2)+'.h5'
_custom_objects = get_custom_objects()
encModel1 = tf.keras.models.load_model(encoder_address1, custom_objects=_custom_objects)
encModel2 = tf.keras.models.load_model(encoder_address2, custom_objects=_custom_objects)
#=======================================================================================================================
#=======================================================================================================================
# Encoding batch_size = 64
encode_feature1 = encModel1.predict(data_test, EN_BATCH_SIZE)
encode_feature2 = encModel2.predict(data_test, EN_BATCH_SIZE)
if encode_feature1.ndim != 2 or encode_feature2.ndim != 2:
    print("Invalid dimension of feedback bits sequence")
elif np.all(np.multiply(encode_feature1, encode_feature1) != encode_feature1) or  np.all(np.multiply(encode_feature2, encode_feature2) != encode_feature2):
    print("Invalid form of feedback bits sequence")
elif np.shape(encode_feature1)[-1] != 48 or np.shape(encode_feature2)[-1] != 128:
    print("Invalid length of feedback bits sequence")
else:
    print("Feedback bits length is " + str(np.shape(encode_feature1)[-1]) + " and " + str(np.shape(encode_feature2)[-1]))
    np.save('./encOutput_48.npy', encode_feature1)
    np.save('./encOutput_128.npy', encode_feature2)
    print('Finished!')
#=======================================================================================================================
#=======================================================================================================================