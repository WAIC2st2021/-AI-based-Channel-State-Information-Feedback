#=======================================================================================================================
#=======================================================================================================================
"""在modelDesign_*.py加载自定义的其他模型时，请在modelDesign_*.py中使用如下代码获取模型路径："""
import os
import sys
# 获取当前文件所在的路径部分
CUR_DIRNAME = os.path.dirname(__file__)
# 你自定义的模型名称
# YOUR_MODEL_NAME = 'your_model.pth.tar'  # Pytorch模型
YOUR_MODEL_NAME = 'your_model.h5'   # TensorFlow模型
# 拼接为你自定义模型的完整路径
YOUR_MODEL_PATH = os.path.join(CUR_DIRNAME, YOUR_MODEL_NAME)

#=======================================================================================================================
#=======================================================================================================================
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
#=======================================================================================================================
#=======================================================================================================================
# Number to Bit Defining Function Defining
def Num2Bit(Num, B):
    Num_ = Num.numpy()
    bit = (np.unpackbits(np.array(Num_, np.uint8), axis=1).reshape(-1, Num_.shape[1], 8)[:, :, (8-B):]).reshape(-1,
                                                                                                            Num_.shape[
                                                                                                                1] * B)
    bit.astype(np.float32)
    return tf.convert_to_tensor(bit, dtype=tf.float32)
# Bit to Number Function Defining
def Bit2Num(Bit, B):
    Bit_ = Bit.numpy()
    Bit_.astype(np.float32)
    Bit_ = np.reshape(Bit_, [-1, int(Bit_.shape[1] / B), B])
    num = np.zeros(shape=np.shape(Bit_[:, :, 1]))
    for i in range(B):
        num = num + Bit_[:, :, i] * 2 ** (B - 1 - i)
    return tf.cast(num, dtype=tf.float32)
#=======================================================================================================================
#=======================================================================================================================
# Quantization and Dequantization Layers Defining
@tf.custom_gradient
def QuantizationOp(x, B):
    step = tf.cast((2 ** B), dtype=tf.float32)
    result = tf.cast((tf.round(x * step - 0.5)), dtype=tf.float32)
    result = tf.py_function(func=Num2Bit, inp=[result, B], Tout=tf.float32)
    def custom_grad(dy):
        grad = dy
        return (grad, grad)
    return result, custom_grad
class QuantizationLayer(tf.keras.layers.Layer):
    def __init__(self, B,**kwargs):
        self.B = B
        super(QuantizationLayer, self).__init__()
    def call(self, x):
        return QuantizationOp(x, self.B)
    def get_config(self):
        # Implement get_config to enable serialization. This is optional.
        base_config = super(QuantizationLayer, self).get_config()
        base_config['B'] = self.B
        return base_config
@tf.custom_gradient
def DequantizationOp(x, B):
    x = tf.py_function(func=Bit2Num, inp=[x, B], Tout=tf.float32)
    step = tf.cast((2 ** B), dtype=tf.float32)
    result = tf.cast((x + 0.5) / step, dtype=tf.float32)
    def custom_grad(dy):
        grad = dy * 1
        return (grad, grad)
    return result, custom_grad
class DeuantizationLayer(tf.keras.layers.Layer):
    def __init__(self, B,**kwargs):
        self.B = B
        super(DeuantizationLayer, self).__init__()
    def call(self, x):
        return DequantizationOp(x, self.B)
    def get_config(self):
        base_config = super(DeuantizationLayer, self).get_config()
        base_config['B'] = self.B
        return base_config
#=======================================================================================================================
#=======================================================================================================================
def Encoder(x,feedback_bits):
    B=2
    def add_common_layers(y):
        y = keras.layers.BatchNormalization()(y)
        y = keras.layers.LeakyReLU()(y)
        return y
    x = layers.Flatten()(x)
    x = layers.Dense(256)(x)
    x = add_common_layers(x)
    x = layers.Dense(units=int(feedback_bits / B), activation='sigmoid')(x)
    encoder_output = QuantizationLayer(B)(x)
    return encoder_output

def Decoder(x,feedback_bits):
    B=2
    def add_common_layers(y):
        y = keras.layers.BatchNormalization()(y)
        y = keras.layers.LeakyReLU()(y)
        return y
    decoder_input = DeuantizationLayer(B)(x)
    print(f"decoder_input={decoder_input}")
    x = tf.keras.layers.Reshape((-1, int(feedback_bits/B)))(decoder_input)
    print(f"decoder_input Reshape之后，x.shape={x.shape}")
    x = layers.Dense(768, activation='sigmoid')(x)
    x = layers.Reshape((32, 12, 2))(x)

    x = layers.Conv2D(32, (3, 3), padding='SAME', data_format='channels_last')(x)
    x = add_common_layers(x)
    decoder_output = layers.Conv2D(2, kernel_size=(3, 3), padding='same', data_format='channels_last')(x)
    decoder_output = layers.Flatten()(decoder_output)
    return decoder_output
#=======================================================================================================================
#=======================================================================================================================
# Testing Function Defining
def cos_sim(vector_a, vector_b):
    vector_a = np.mat(vector_a)
    vector_b = np.mat(vector_b)
    num = vector_a * vector_b.H
    num1 = np.sqrt(vector_a * vector_a.H)
    num2 = np.sqrt(vector_b * vector_b.H)
    cos = (num / (num1*num2))
    return cos

def cal_score(w_true, w_pre, NUM_SAMPLES, NUM_SUBBAND):
    img_total = 64
    num_sample_subband = NUM_SAMPLES * NUM_SUBBAND
    W_true = np.reshape(w_true, [num_sample_subband, img_total])
    W_pre = np.reshape(w_pre, [num_sample_subband, img_total])
    W_true2 = W_true[0:num_sample_subband, 0:int(img_total):2] + 1j*W_true[0:num_sample_subband, 1:int(img_total):2]
    W_pre2 = W_pre[0:num_sample_subband, 0:int(img_total):2] + 1j*W_pre[0:num_sample_subband, 1:int(img_total):2]
    score_cos = 0
    for i in range(num_sample_subband):
        W_true2_sample = W_true2[i:i+1,]
        W_pre2_sample = W_pre2[i:i+1,]
        score_tmp = cos_sim(W_true2_sample, W_pre2_sample)
        score_cos = score_cos + abs(score_tmp)*abs(score_tmp)
    score_cos = score_cos / num_sample_subband
    return score_cos

def get_custom_objects():
    return {"QuantizationLayer":QuantizationLayer,"DeuantizationLayer":DeuantizationLayer}
#=======================================================================================================================
#=======================================================================================================================