#=======================================================================================================================
#=======================================================================================================================
from tensorflow import keras
import numpy as np
from tensorflow.keras.callbacks import ModelCheckpoint
import scipy.io as sio
from tensorflow.keras.losses import cosine_similarity
import tensorflow as tf

config = tf.compat.v1.ConfigProto(allow_soft_placement=False, log_device_placement=False)
config.gpu_options.allow_growth = True
session = tf.compat.v1.Session(config=config)

#=======================================================================================================================
#=======================================================================================================================
# Parameters Setting
NUM_FEEDBACK_BITS = 128
if NUM_FEEDBACK_BITS == 128:
    from modelDesign_128 import *
elif NUM_FEEDBACK_BITS == 48:
    from modelDesign_48 import *
CHANNEL_SHAPE_DIM1 = 12
CHANNEL_SHAPE_DIM2 = 32
CHANNEL_SHAPE_DIM3 = 2
CHANNEL_SHAPE_DIM_TOTAL = CHANNEL_SHAPE_DIM1 * CHANNEL_SHAPE_DIM2 * CHANNEL_SHAPE_DIM3
NUM_SAMPLES = 600000 # 此行不同
#=======================================================================================================================
#=======================================================================================================================
# Data Loading
mat = sio.loadmat('channelData/W_train.mat')
data = mat['W_train']
#=======================================================================================================================
# 此行为跑数据样例版本的代码和该文件的shape不同
# data = np.reshape(data, (NUM_SAMPLES, CHANNEL_SHAPE_DIM1, CHANNEL_SHAPE_DIM2, 1))
#=======================================================================================================================
data = np.reshape(data, (NUM_SAMPLES, CHANNEL_SHAPE_DIM1, CHANNEL_SHAPE_DIM2, CHANNEL_SHAPE_DIM3))
# 没有了实部和虚部
data_train = np.reshape(data, [NUM_SAMPLES, -1])
#=======================================================================================================================
#=======================================================================================================================
# Model Constructing
# Encoder
encInput = keras.Input(shape=(CHANNEL_SHAPE_DIM_TOTAL))
encOutput = Encoder(encInput, NUM_FEEDBACK_BITS)
encModel = keras.Model(inputs=encInput, outputs=encOutput, name='Encoder')
# Decoder
decInput = keras.Input(shape=(NUM_FEEDBACK_BITS,))
decOutput = Decoder(decInput, NUM_FEEDBACK_BITS)
decModel = keras.Model(inputs=decInput, outputs=decOutput, name="Decoder")
# Autoencoder
autoencoderInput = keras.Input(shape=(CHANNEL_SHAPE_DIM_TOTAL))
autoencoderOutput = decModel(encModel(autoencoderInput))
autoencoderModel = keras.Model(inputs=autoencoderInput, outputs=autoencoderOutput, name='Autoencoder')
# Comliling
autoencoderModel.compile(optimizer='adam', loss='mse', metrics =[cosine_similarity])
autoencoderModel.summary()
#=======================================================================================================================
#=======================================================================================================================
# Model Training  epochs 500 --> 2
autoencoderModel.fit(x=data_train, y=data_train, batch_size=64, epochs=2, verbose=2, validation_split=0.1)
#=======================================================================================================================
#=======================================================================================================================
# Model Saving
# Encoder Saving
encModel.save('./modelSubmit/encoder_'+str(NUM_FEEDBACK_BITS)+'.h5')
# Decoder Saving
decModel.save('./modelSubmit/decoder_'+str(NUM_FEEDBACK_BITS)+'.h5')
print('Training for '+str(NUM_FEEDBACK_BITS)+' bits is finished!')
#=======================================================================================================================
#=======================================================================================================================
